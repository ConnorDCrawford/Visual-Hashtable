package visual.hashtable;

public class Main {

    public static void main(String[] args) {
        MyHashtableVisualizer visualizer = new MyHashtableVisualizer();
    }
}
